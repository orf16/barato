create function copiarproductos(id_tarea bigint) returns void
  language plpgsql
as
$$
declare
idProdl BIGINT;
cantidad integer;
idtienda integer;
nombrel character varying(255); 
idMaxproducto BIGINT;
reg          RECORD;
cur_productos CURSOR FOR SELECT * FROM producto_twebscr_hist
				where "idtarea"=ID_Tarea and "precio" > 0 order by "nombre";
begin


idtienda:=(select a."idtienda" as id from "almacen" a
where a.idalmacen = (select idalmacen from tareawebscraper where "idtarea"=ID_Tarea));

UPDATE producto_tienda set estado=false
 where tienda_idtienda = idtienda;					 

 FOR reg IN cur_productos LOOP
 
 nombrel:=reg.nombre; 
idProdl:=NULL;					 
IF reg.codigotienda IS NOT NULL THEN
					 
idProdl:=(select p."producto_idproducto" as id from "producto_tienda" p
where p."codigotienda" = reg.codigotienda and p."tienda_idtienda"= idtienda);
					 
END IF;
					 
IF idProdl IS NULL THEN						 
		 
idProdl:=(select p."producto_idproducto" as id from "producto_tienda" p
where UPPER(p."nombre") like UPPER(nombrel) and p."tienda_idtienda"= idtienda);
END IF;
					 
					 
IF idProdl IS NULL THEN	
								   
idProdl:=(select p."idproducto" as id from "producto" p
where UPPER(p."nombre") like UPPER(nombrel));	
								   
END IF;									   
								   

IF idProdl IS NULL THEN
								   
idProdl:=(SELECT nextval('producto_idproducto_seq'));
INSERT INTO producto(idproducto,nombre,detalle,direccion_imagen)
values (idProdl,reg.nombre,reg.detalle,reg.direccion_imagen);

INSERT INTO productoxcategoria(producto_idproducto,categoria_idcategotia,valor,valor_unidad)
values(idProdl,reg.idcategoria,reg.precio,reg.precio);
						 
ELSE
						 
/*UPDATE producto SET nombre=reg.nombre,direccion_imagen=reg.direccion_imagen where idproducto=idProdl;*/
UPDATE producto SET direccion_imagen=reg.direccion_imagen where idproducto=idProdl;							 
UPDATE productoxcategoria SET valor=reg.precio, valor_unidad=reg.precio,categoria_idcategotia=reg.idcategoria where producto_idproducto=idProdl;
					 
END IF;
						 
				 
 cantidad:=(select count(1) from "producto_tienda" t
where t.producto_idproducto = idProdl and tienda_idtienda = idtienda );

IF cantidad > 0  THEN
						 
UPDATE producto_tienda set nombre=reg.nombre,codigotienda = reg.codigotienda,valor = reg.precio , valor_unidad=reg.precio, estado = true
where producto_idproducto = idProdl and tienda_idtienda = idtienda;					 

ELSE

INSERT INTO producto_tienda(producto_idproducto,tienda_idtienda,nombre,valor,valor_unidad,estado,codigotienda)
VALUES(idProdl,idtienda,reg.nombre,reg.precio,reg.precio,true,reg.codigotienda);						 
END IF;	
						 
	/*							 
						 
cantidad:=(select count(1) from "producto_tienda_cadena" t
where t.producto_idproducto = idProdl and tienda_idtienda = idtienda );

IF cantidad > 0  THEN
UPDATE producto_tienda_cadena set nombre=reg.nombre , valor=reg.precio , valor_unidad=reg.precio, estado = true
where producto_idproducto = idProdl and tienda_idtienda = idtienda;					 

ELSE

INSERT INTO producto_tienda_cadena(producto_idproducto,tienda_idtienda,nombre,valor,valor_unidad,estado)
VALUES(idProdl,idtienda,reg.nombre,reg.precio,reg.precio,true);						 
END IF;							 
	*/				 
		
						 
					 
END LOOP;
						 
UPDATE public.tareawebscraper set productoscopiados=true WHERE "idtarea"=ID_Tarea;
	
						 
end
$$;

alter function copiarproductos(bigint) owner to beyodntest;

