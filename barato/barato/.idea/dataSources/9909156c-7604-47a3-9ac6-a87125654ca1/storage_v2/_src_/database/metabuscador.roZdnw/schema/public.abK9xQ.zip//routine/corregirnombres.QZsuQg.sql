create function corregirnombres(id_tarea bigint) returns void
  language plpgsql
as
$$
declare
idProdl BIGINT;
cantidad integer;
idtienda integer;
nombrel character varying(255); 
idMaxproducto BIGINT;
reg          RECORD;
cur_productos CURSOR FOR SELECT * FROM producto_tienda
				order by "nombre";
begin
				 

 FOR reg IN cur_productos LOOP
 
 nombrel:=reg.nombre; 
				 
idProdl:=reg.producto_idproducto; 


UPDATE producto set "nombre" = nombrel where "idproducto" = idProdl ;


						 
END LOOP;
end
$$;

alter function corregirnombres(bigint) owner to beyodntest;

