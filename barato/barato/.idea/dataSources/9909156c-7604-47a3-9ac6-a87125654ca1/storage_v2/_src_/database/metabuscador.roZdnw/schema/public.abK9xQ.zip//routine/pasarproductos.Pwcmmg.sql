create function pasarproductos() returns trigger
  language plpgsql
as
$$
BEGIN 
 IF (NEW.fechahorafin IS NOT NULL) THEN
 select copiarproductos(NEW.idtarea);
 END IF;
 
 RETURN NEW;
 END;
$$;

alter function pasarproductos() owner to beyodntest;

